import CommonIcon from './common-icon.vue'
export default CommonIcon
