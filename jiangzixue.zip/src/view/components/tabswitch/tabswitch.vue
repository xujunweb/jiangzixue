<template>

</template>
<script>
export default {
  name: "tabswitch"
}
</script>

<style scoped lang="less">

</style>
